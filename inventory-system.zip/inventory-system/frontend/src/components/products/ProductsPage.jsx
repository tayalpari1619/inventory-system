import { useState, useEffect, useCallback } from "react";
import toast from "react-hot-toast";
import { productApi } from "../../services/resources";
import Modal from "../common/Modal";
import ConfirmDialog from "../common/ConfirmDialog";
import { LoadingSpinner, PageHeader, EmptyState } from "../common/index.jsx";

const EMPTY_FORM = { name: "", sku: "", price: "", quantity_in_stock: "" };

function ProductForm({ initial = EMPTY_FORM, onSubmit, loading, submitLabel = "Save" }) {
  const [form, setForm] = useState(initial);
  const [errors, setErrors] = useState({});

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = "Name is required.";
    if (!form.sku.trim()) e.sku = "SKU is required.";
    if (!form.price || isNaN(form.price) || Number(form.price) <= 0) e.price = "Price must be > 0.";
    if (form.quantity_in_stock === "" || isNaN(form.quantity_in_stock) || Number(form.quantity_in_stock) < 0)
      e.quantity_in_stock = "Quantity must be ≥ 0.";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!validate()) return;
    onSubmit({
      name: form.name.trim(),
      sku: form.sku.trim().toUpperCase(),
      price: Number(form.price),
      quantity_in_stock: Number(form.quantity_in_stock),
    });
  };

  const field = (key, label, type = "text", extra = {}) => (
    <div>
      <label className="label">{label}</label>
      <input
        className="input"
        type={type}
        value={form[key]}
        onChange={(e) => setForm({ ...form, [key]: e.target.value })}
        {...extra}
      />
      {errors[key] && <p className="error-text">{errors[key]}</p>}
    </div>
  );

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {field("name", "Product Name")}
      {field("sku", "SKU")}
      {field("price", "Price ($)", "number", { step: "0.01", min: "0.01" })}
      {field("quantity_in_stock", "Quantity in Stock", "number", { min: "0", step: "1" })}
      <div className="flex justify-end gap-3 pt-2">
        <button type="submit" className="btn-primary" disabled={loading}>
          {loading ? "Saving…" : submitLabel}
        </button>
      </div>
    </form>
  );
}

export default function ProductsPage() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editTarget, setEditTarget] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const { data } = await productApi.list();
      setProducts(data);
    } catch (err) {
      toast.error("Failed to load products.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  const handleCreate = async (payload) => {
    setSaving(true);
    try {
      await productApi.create(payload);
      toast.success("Product created.");
      setModalOpen(false);
      fetchProducts();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleUpdate = async (payload) => {
    setSaving(true);
    try {
      await productApi.update(editTarget.id, payload);
      toast.success("Product updated.");
      setEditTarget(null);
      fetchProducts();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async () => {
    setDeleting(true);
    try {
      await productApi.delete(deleteTarget.id);
      toast.success("Product deleted.");
      setDeleteTarget(null);
      fetchProducts();
    } catch (err) {
      toast.error(err.message);
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div>
      <PageHeader
        title="Products"
        subtitle={`${products.length} product${products.length !== 1 ? "s" : ""}`}
        action={
          <button className="btn-primary" onClick={() => setModalOpen(true)}>
            + Add Product
          </button>
        }
      />

      {loading ? (
        <LoadingSpinner />
      ) : products.length === 0 ? (
        <EmptyState icon="📦" title="No products yet" description="Click 'Add Product' to get started." />
      ) : (
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                {["Name", "SKU", "Price", "Stock", "Actions"].map((h) => (
                  <th key={h} className="px-4 py-3 text-left font-semibold text-slate-500 text-xs uppercase tracking-wide">
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {products.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 font-medium text-slate-900">{p.name}</td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-600">{p.sku}</td>
                  <td className="px-4 py-3">${Number(p.price).toFixed(2)}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
                      p.quantity_in_stock <= 10
                        ? "bg-red-100 text-red-700"
                        : "bg-green-100 text-green-700"
                    }`}>
                      {p.quantity_in_stock}
                    </span>
                  </td>
                  <td className="px-4 py-3 flex gap-2">
                    <button
                      className="btn-secondary text-xs py-1 px-3"
                      onClick={() => setEditTarget(p)}
                    >
                      Edit
                    </button>
                    <button
                      className="btn-danger text-xs py-1 px-3"
                      onClick={() => setDeleteTarget(p)}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Create Modal */}
      <Modal isOpen={modalOpen} onClose={() => setModalOpen(false)} title="Add Product">
        <ProductForm onSubmit={handleCreate} loading={saving} submitLabel="Create Product" />
      </Modal>

      {/* Edit Modal */}
      <Modal isOpen={!!editTarget} onClose={() => setEditTarget(null)} title="Edit Product">
        {editTarget && (
          <ProductForm
            initial={{ ...editTarget, price: editTarget.price, quantity_in_stock: editTarget.quantity_in_stock }}
            onSubmit={handleUpdate}
            loading={saving}
            submitLabel="Update Product"
          />
        )}
      </Modal>

      {/* Delete Confirm */}
      <ConfirmDialog
        isOpen={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        loading={deleting}
        title="Delete Product"
        message={`Are you sure you want to delete "${deleteTarget?.name}"? This cannot be undone.`}
      />
    </div>
  );
}
